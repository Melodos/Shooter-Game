#! python3
# shootergame.py

import pygame, random

pygame.init()

# CONSTANTS ------
screen_width = 800
screen_height = 600
screen_size = (screen_width, screen_height)
window_title = "Shooter Game"
black = (0, 0, 0)
white = (255, 255, 255)
red = (255, 0, 0)
green = (0, 255, 0)
blue = (0, 0, 255)
yellow = (255, 255, 0)
BG_color = black
refresh_rate = 60

# Class ------
class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()

        self.image = pygame.transform.scale(
            pygame.image.load("fallenreality_heart.png").convert(),
            (16, 16)
        )
        self.image.set_colorkey(white)

        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

        self.walls = None
        self.vel_x = 0
        self.vel_y = 0
    
    def update(self):
        # Updates the location of our player
        self.rect.x += self.vel_x

        wall_hit_list = pygame.sprite.spritecollide(self, self.walls, False)
        for wall in wall_hit_list:
            # If we're moving right: Line up right side of sprite to left side of wall
            if self.vel_x > 0:
                self.rect.right = wall.rect.left

            else:
                self.rect.left = wall.rect.right

        self.rect.y += self.vel_y

        # Wall Collision
        wall_hit_list = pygame.sprite.spritecollide(self, self.walls, False)
        for wall in wall_hit_list:
            if self.vel_y > 0:
                self.rect.bottom = wall.rect.top

            else:
                self.rect.top = wall.rect.bottom

    # Changing player velocity
    def change_vel(self, x, y):
        self.vel_x += x
        self.vel_y += y

    # Resetting player position
    def reset_pos(self, x, y):
        self.rect.x = (screen_width // 2)
        self.rect.y = (screen_height // 2)

    def blink(self):
        if self.vel_y == -2:
            self.rect.y -= 60
            if self.rect.y <= 5:
                self.rect.y += 60
        elif self.vel_y == 2:
            self.rect.y += 60
            if self.rect.y >= screen_height - 5:
                self.rect.y -= 60

        if self.vel_x == -2:
            self.rect.x -= 60
            if self.rect.x <= 5:
                self.rect.x += 60
        elif self.vel_x == 2:
            self.rect.x += 60
            if self.rect.x >= screen_width - 5:
                self.rect.x -= 60

# Generates the Wall Class
class Wall(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height):
        super().__init__()

        self.image = pygame.Surface([width, height])
        self.image.fill(white)

        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

# Generates the Bullet Class
class Bullet(pygame.sprite.Sprite):
    velocity = 15

    def __init__(self):
        super().__init__()
        
        self.image = pygame.Surface ([5, 60])
        self.image.fill(yellow)
        self.rect = self.image.get_rect()

    # Updates the velocity of the bullet
    def update(self):
        self.rect.y -= self.velocity
        

class Enemy(pygame.sprite.Sprite):
    # Represents an enemy in our world
    def __init__(self, color, width, height):
        super().__init__()

        self.image = pygame.transform.scale(
            pygame.image.load("flames_proj.png").convert(),
            (15, 25)
        )
        self.image.set_colorkey(black)

        # Mathematical representation of our enemy
        self.rect = self.image.get_rect() # ->[x,y,width,height]
        self.vel_x = -2
        self.randvel = random.randint(3, 6) # modify the variables for varying patterns
        # Note: Don't set either integers over 9 or you'll start screaming from the bullet speed

    def reset_pos(self):
        self.rect.x = random.randrange(screen_width - 25)
        self.rect.y = random.randrange(-100, -10)

    def update(self):
        # Move the block one pixel down per tick
        self.rect.y += self.randvel
        self.rect.x += self.vel_x

        if self.rect.y > screen_height:
            self.reset_pos()
        elif self.rect.x < 5:
            self.vel_x = -self.vel_x
        elif self.rect.x > screen_width - 25:
            self.vel_x = -self.vel_x

class Enemy2(pygame.sprite.Sprite):
    # Represents an enemy in our world
    def __init__(self, color, width, height):
        super().__init__()

        self.image = pygame.Surface ([30, screen_height])
        self.image.fill(red)

        # Mathematical representation of our enemy
        self.rect = self.image.get_rect() # ->[x,y,width,height]

    def reset_pos(self):
        self.rect.x = random.randrange(screen_width - 60)
        self.rect.y = -(screen_height)

    def update(self):
        # Move the block one pixel down per tick
        self.rect.y += 12 # manipulate this number to determine the speed of this monster

        if self.rect.y > screen_height:
            self.reset_pos()

class Background(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()

        self.image = pygame.transform.scale(
            pygame.image.load("NinoAnger.png").convert(),
            (96, 160)
        )
        self.image.set_colorkey(white)

        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
# Functions ------

def main():
    # Static Variables ------
    player_speed = 2
    # Local Variable ------
    screen = pygame.display.set_mode(screen_size)
    clock = pygame.time.Clock()
    done = False # controls main loop
    font = pygame.font.SysFont("Arial", 25, bold=True)
    pygame.mouse.set_visible(False)
    titlestart = 0

    health = 10
    num_enemy = 50 # Determines amount of flame projectiles
    num_enemy2 = 4 # Determines amount of red lasers
    score = 0
    highscore = 0

    pygame.display.set_caption(window_title)
    pygame.mixer.music.load("it's not over til it's over.mp3")
    pygame.mixer.music.play(-1)

    wall_sprite_list = pygame.sprite.Group()
    all_sprites_list = pygame.sprite.Group()

    wall = Wall(0, 0, 5, 595)
    wall2 = Wall(0, 0, 800, 5)
    wall3 = Wall(795, 0, 5, 595)
    wall4 = Wall(0, 595, 800, 5)
    wall_sprite_list.add(wall, wall2, wall3, wall4)
    all_sprites_list.add(wall, wall2, wall3, wall4)

    # Add the player
    player = Player(screen_width // 2, screen_height // 2)
    player.walls = wall_sprite_list
    all_sprites_list.add(player)

    # Add the background image
    background = Background(screen_width // 2 - 48, 80)
    all_sprites_list.add(background)

    # Add the bullet lists
    bullet_list = pygame.sprite.Group()

    # Add the enemies
    enemy_list = pygame.sprite.Group()
    for i in range(num_enemy):
        enemy = Enemy(white, 5, 60)

        enemy.rect.x = random.randrange(screen_width - 5)
        enemy.rect.y = random.randrange(screen_height)

        enemy_list.add(enemy)
        all_sprites_list.add(enemy)
    
    enemy_list2 = pygame.sprite.Group()
    for i in range(num_enemy2):
        enemy2 = Enemy2(red, 30, screen_height)

        enemy_list2.add(enemy2)
        all_sprites_list.add(enemy2)

    # Main Loop
    while not done:
        # Event Handler
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                done = True
            
            # Lets the player move
            elif event.type == pygame.KEYDOWN:
                titlestart = 1
                if event.key == pygame.K_UP:
                    player.change_vel(0, -player_speed)
                elif event.key == pygame.K_DOWN:
                    player.change_vel(0, player_speed)
                elif event.key == pygame.K_LEFT:
                    player.change_vel(-player_speed, 0)
                elif event.key == pygame.K_RIGHT:
                    player.change_vel(player_speed, 0)
                elif event.key == pygame.K_LSHIFT and health > 0:
                    bullet = Bullet()
                    bullet.rect.x = player.rect.centerx - 2
                    bullet.rect.y = player.rect.y - 26
                    # add the bullet to all_sprites
                    all_sprites_list.add(bullet)
                    bullet_list.add(bullet)
                elif event.key == pygame.K_z:
                    # Lets the player teleport a brief distance
                    player.blink()
                elif event.key == pygame.K_r:
                    # Resets the game
                    health = 10
                    score = 0
                    player.rect.x = (screen_width // 2)
                    player.rect.y = (screen_height // 2)
                elif event.key == pygame.K_c:
                    # Resets the player's position
                    player.rect.x = (screen_width // 2)
                    player.rect.y = (screen_height // 2)

            # Stops the player after moving        
            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_UP:
                    player.change_vel(0, player_speed)
                elif event.key == pygame.K_DOWN:
                    player.change_vel(0, -player_speed)
                elif event.key == pygame.K_LEFT:
                    player.change_vel(player_speed, 0)
                elif event.key == pygame.K_RIGHT:
                    player.change_vel(-player_speed, 0)
            

        # Game Logic ------
        all_sprites_list.update()

        # Bullet movement
        
            

        # List of all enemies collided for each bullet
        for bullet in bullet_list:
            bullet_enemy_hit_list = pygame.sprite.spritecollide(bullet, enemy_list, False)
            for enemy in bullet_enemy_hit_list:
                enemy.reset_pos()
                # bullet.rect.y = -60
                bullet_list.remove(bullet)
                all_sprites_list.remove(bullet)
                score += 1
            if bullet.rect.y <= -60:
                bullet_list.remove(bullet)
                all_sprites_list.remove(bullet)

        # List of all blocks Player collides with
        enemies_collided = pygame.sprite.spritecollide(player, enemy_list, False)
        for enemy in enemies_collided:
            health -= 1
            enemy.reset_pos()
        
        # Deals damage to the player every frame
        enemies_collided2 = pygame.sprite.spritecollide(player, enemy_list2, False)
        for enemy2 in enemies_collided2:
            health -= 1
        
        # Highscore saving
        highscore_file = open("./highscore.txt")
        highscore_content = highscore_file.read() # reads the whole file in one string
        highscore_file.close()
        if highscore_content != "":
            highscore = int(highscore_content)

        if highscore < score:
            highscore = score
            with open("highscore.txt", "w") as file:
                file.write(str(highscore)) # Saves the score to a txt file.
        else:
            highscore = highscore

        # Drawing ------
        
        # Title Screen
        if titlestart == 0:
            screen.fill(BG_color)
            titlescreen = font.render(("Vs Nino. Press any button to begin."), False, white)
            screen.blit(titlescreen, (screen_width // 2 - 175, 30))
            titlescreen2 = font.render(("You brought this on yourself."), False, white)
            screen.blit(titlescreen2, (screen_width // 2 - 150, 60))

            health = 10

            pygame.display.flip()

        # Handle the health reaching 0
        elif health <= 0:
            screen.fill(BG_color)

            gameover = font.render(("Game Over! You lose."), False, white)
            screen.blit(gameover, (screen_width // 2 - 110, 30))
            scorescreen = font.render((f"Final Score: {score}. Press R to restart."), False, white)
            screen.blit(scorescreen, (screen_width // 2 - 180, 60))
            highscore_screen = font.render((f"High Score: {highscore}"), False, white)
            screen.blit(highscore_screen, (screen_width // 2 - 60, 90))

            pygame.display.flip()
        
        # Loading the game itself
        else:
            screen.fill(BG_color)

            all_sprites_list.draw(screen)

            hitcount = font.render((f"{health} health remaining! (Press C to reset position if you get stuck.)"), False, white)
            screen.blit(hitcount, (30, 30))
            scorescreen = font.render((f"Score: {score}. Shoot enemies to gain score."), False, white)
            screen.blit(scorescreen, (screen_width // 2 - 210, 60))
            instruction = font.render(("Arrow keys to move, LShift to shoot, Z to blink(short teleport)"), False, white)
            screen.blit(instruction, (40, 90))

            pygame.display.flip()

        # Clock Tick ------
        clock.tick(refresh_rate)
        

if __name__ == "__main__":
    main()